# Trackmania 2020 - Materials Library

Asset library extension for Blender 5.3 and newer. 825 Materials Only entries.
Enable Online Access, install this extension and enable the library under
Preferences > Asset Libraries. Select it in the Asset Browser. Materials download
on demand, including packed textures. No terminal or local server is needed.

Refresh Remote Listing checks the current asset listing. Downloaded materials
are cached by Blender. To download everything, clear search/catalog filters,
select all assets and choose Download Assets. Updating the library does not
replace materials already appended to a scene. Disable the earlier pilot
library if installed to avoid confusing duplicate entries.

Complete-only / Preview only entries and MaterialLib.txt are excluded. Blendermania
supplies its own export setup. Existing offline packages remain available.
Install page: https://bigthirstytm.github.io/TM2020-Material-Assets-Library/
